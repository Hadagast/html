# Cotação do Dollar para Real

cotacao = float (input('Qual a cotação do dolar em reais?'))
valreal = float (input('Quanto você tem no cofre do Hotel?'))
total = cotacao*valreal
print()
print('Você tem R$',total,'no seu cofre')