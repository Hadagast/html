# Média dos alunos

nome = input("Digite o nome do aluno:")
n1 = float (input('Digite a 1º nota:'))
n2 = float (input('Digite a 2º nota:'))
n3 = float (input('Digite a 3º nota:'))
n4 = float (input('Digite a 4º nota:'))
media = (n1+n2+n3+n4)/4
print("A média do aluno",nome,"é de:",media)