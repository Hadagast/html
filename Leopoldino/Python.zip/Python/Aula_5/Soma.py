# Programa para calcular a soma de 2 números

print('Programa para calcular dois números')
n1 = float(input("Entre com o primeiro número:"))
n2 = float(input("Entre com o segundo número:"))
soma = n1+n2
print('A soma é igual a:',soma)