# Alterando os valores de sep e end na função print
ano1='1980'
ano2='1990'
ano3='2000'
ano4='2010'
texto="Alterando o valor de sep."
print(texto)
print(ano1,ano2,ano3,ano4,sep='--->')
#pula uma linha
print ()
texto="Alterando o valor de sep e end."
print(texto)
print(ano1,ano2,ano3,ano4,sep = '--->',end='...\n')
