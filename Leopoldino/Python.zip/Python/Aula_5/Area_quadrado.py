# Calcular area do quadrado

lado = a = int(input("digite o lado do quadrado:"))
perimetro = lado * 4
area = lado * lado
print("perimetro",perimetro)
print("area:",area)