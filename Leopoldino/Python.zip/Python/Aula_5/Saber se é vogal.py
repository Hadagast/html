#descobrir se é vogal

letra = input("Digite uma letra:")
if letra=='a' or letra=='e' or letra=='i' or letra=='o' or letra=='u' or letra=='A' or letra=='E' or letra=='I' or letra=='O' or letra=='U':
 print('Vogal')
else:
 print("Consoante")