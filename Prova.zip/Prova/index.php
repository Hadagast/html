<html>
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="index.css">
    </head>
    <body>
        <div>
            <nav id="menu">
                <ul>
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Serviços</a></li>
                    <li><a href="#">Dicas</a></li>
                    <li><a href="#">Contato</a></li>
                    <li><a href="#">Acesso ao Sistemas</a></li>
                </ul>
            </nav>
        </div>
        <div>
            <h3>Login<h3>
                <form method="post">
                    <table>
                        <tr>
                            <td>Usuário: </td>
                            <td><input type="text" name="usuario"></td>
                        </tr>
                        <tr>
                            <td>Senha: </td>
                            <td><input type="password" name="senha"></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td colspan="2" align="right"><button type="submit">Enviar</td>
                        </tr>
                    </table>
                </form>
        </div>
        <?php 
                    $nome = "adm";
                    $senha = "123";
                    

                    if ($_POST["usuario"] == $nome && $_POST["senha"] == $senha){        
                        header("Location: cadastro.html");
                    }else {
                        echo "Usuário ou senha inválido!";
                    }         
                ?>
    </body>
</html>